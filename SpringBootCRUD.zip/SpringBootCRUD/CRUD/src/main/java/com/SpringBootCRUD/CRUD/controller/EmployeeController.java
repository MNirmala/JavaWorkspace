package com.SpringBootCRUD.CRUD.controller;

import com.SpringBootCRUD.CRUD.repository.EmployeeRepository;
import com.SpringBootCRUD.CRUD.service.EmployeeService;
import org.springframework.stereotype.Controller;
import com.SpringBootCRUD.CRUD.model.Employee;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
@Controller
public class EmployeeController {
    @Autowired
    private EmployeeService employeeService;

    @GetMapping("/Employees")
    public String listAll(Model model) {
        List<Employee> listEmployees = employeeService.getAllEmployees();
        model.addAttribute("listEmployees",listEmployees);
        return "index";
    }
}
