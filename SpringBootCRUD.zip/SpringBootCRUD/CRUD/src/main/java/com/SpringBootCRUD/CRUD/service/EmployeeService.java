package com.SpringBootCRUD.CRUD.service;
import com.SpringBootCRUD.CRUD.model.Employee;
import java.util.List;

public interface EmployeeService {
    List<Employee> getAllEmployees();
}
