package com.SpringBootCRUD.CRUD.service;
import com.SpringBootCRUD.CRUD.model.Employee;
import com.SpringBootCRUD.CRUD.repository.EmployeeRepository;
import com.SpringBootCRUD.CRUD.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class EmployeeServiceImpl implements EmployeeService{
    @Autowired
    private EmployeeRepository employeeRepository;
    @Override
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }
}
