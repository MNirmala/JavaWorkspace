package com.SpringBootCRUD.CRUD.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.SpringBootCRUD.CRUD.model.Employee;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer>{

    List<Employee>findAll();

}
