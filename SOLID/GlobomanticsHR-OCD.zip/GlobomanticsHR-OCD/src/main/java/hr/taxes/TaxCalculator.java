package hr.taxes;
import hr.personnel.Employee;
public interface TaxCalculator {
    double calculate(Employee employee);
}
