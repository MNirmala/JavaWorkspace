package hr.main;

import hr.logging.ConsoleLog;
import hr.persistence.EmployeeFileSerializer;
import hr.persistence.EmployeeRepository;
import hr.personnel.Employee;

import java.util.List;

public class SaveEmployeesMain {
    public static void main(String[] args) {
        // Grab employees
        EmployeeFileSerializer efs= new EmployeeFileSerializer();
        EmployeeRepository repository = new EmployeeRepository(efs);
        List<Employee> employees = repository.findAll();
        ConsoleLog clog=new ConsoleLog();
        // Save all
        for (Employee e : employees){
            try {
                repository.save(e);
                clog.writeInfo("Saved Successfully "+ e.toString());
            }
            catch (Exception ex)
            {
                clog.writeError("Error", ex);
            }
        }
    }
}
